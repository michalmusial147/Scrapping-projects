import requests
from bs4 import BeautifulSoup


def get_links(link):

    return_links = []

    r = requests.get(link)

    soup = BeautifulSoup(r.content, "lxml")

    if r.status_code != 200:
        print("Error.")
    else:
        for link in soup.findAll('a'):
            if link is not None:
                url = link.get('href')
                if url is not None:
                    print(0, "[Scrapper] visiting {}".format(url))
                    return_links.append(link.get('href'))

def recursive_search(links):
    if links:
        for i in links:
            links.append(get_links(i))
        recursive_search(links)


# recursive_search(get_links("https://pl.wikipedia.org/wiki/Wikipedia:Strona_g%C5%82%C3%B3wna"))
recursive_search(get_links("https://www.kis.p.lodz.pl/"))